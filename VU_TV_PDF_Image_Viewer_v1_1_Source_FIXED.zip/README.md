# TV PDF & Image Viewer 1.1

Android TV-oriented source project for a remote-friendly PDF and image viewer.

## Included
- Android TV / Leanback launcher entry
- Android Storage Access Framework picker for USB and shared/internal storage
- PDF rendering using Android PdfRenderer
- JPG and PNG image viewing
- Remote-friendly buttons: Open, Previous/Next, Zoom In/Out, Fit, Bookmark, Go to Page
- Saves last opened document and last PDF page
- Landscape full-screen interface
- Java and Kotlin compilation both target JVM 17

## Build APK
Open this folder in Android Studio with Android SDK Platform 35 and JDK 17, then build `assembleDebug`.

## Important
This is a source project, not a prebuilt APK. It has not yet been tested on the VU 50VIBE-DV hardware. USB visibility is controlled by the Android document picker supplied by the TV firmware. Very large image files may use substantial memory on TVs with 2 GB RAM.
