package com.vu.tvviewer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var pageImage: ImageView
    private lateinit var emptyMessage: TextView
    private lateinit var pageLabel: TextView
    private lateinit var fileName: TextView

    private var descriptor: ParcelFileDescriptor? = null
    private var pdfRenderer: PdfRenderer? = null
    private var imageBitmap: Bitmap? = null
    private var renderedBitmap: Bitmap? = null
    private var currentPage = 0
    private var zoom = 1.0f
    private var isPdf = false
    private var currentUri: Uri? = null

    private val prefs by lazy { getSharedPreferences("tvviewer", MODE_PRIVATE) }
    private val pickFile = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_main)

        pageImage = findViewById(R.id.pageImage)
        emptyMessage = findViewById(R.id.emptyMessage)
        pageLabel = findViewById(R.id.pageLabel)
        fileName = findViewById(R.id.fileName)

        findViewById<Button>(R.id.openButton).setOnClickListener { openPicker() }
        findViewById<Button>(R.id.prevButton).setOnClickListener { changePage(-1) }
        findViewById<Button>(R.id.nextButton).setOnClickListener { changePage(1) }
        findViewById<Button>(R.id.zoomInButton).setOnClickListener { zoom = (zoom * 1.2f).coerceAtMost(4f); displayCurrent() }
        findViewById<Button>(R.id.zoomOutButton).setOnClickListener { zoom = (zoom / 1.2f).coerceAtLeast(0.5f); displayCurrent() }
        findViewById<Button>(R.id.fitButton).setOnClickListener { zoom = 1f; displayCurrent() }
        findViewById<Button>(R.id.bookmarkButton).setOnClickListener { saveBookmark() }
        findViewById<Button>(R.id.jumpButton).setOnClickListener { askPageNumber() }
        findViewById<Button>(R.id.openButton).requestFocus()

        prefs.getString("last_uri", null)?.let { saved ->
            try { loadDocument(Uri.parse(saved), resume = true) } catch (_: Exception) { }
        }
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "image/jpeg", "image/png"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, pickFile)
    }

    @Deprecated("Retained for broad Android TV compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFile && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            loadDocument(uri, resume = false)
        }
    }

    private fun loadDocument(uri: Uri, resume: Boolean) {
        closeDocument()
        try {
            currentUri = uri
            val mime = contentResolver.getType(uri)?.lowercase().orEmpty()
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected document"
            fileName.text = name
            zoom = 1f

            if (mime == "application/pdf" || name.lowercase().endsWith(".pdf")) {
                descriptor = contentResolver.openFileDescriptor(uri, "r")
                    ?: throw IOException("PDF file could not be opened")
                pdfRenderer = PdfRenderer(descriptor!!)
                if (pdfRenderer!!.pageCount < 1) throw IOException("PDF में कोई पेज नहीं है")
                isPdf = true
                val savedPage = if (resume) prefs.getInt("page_${uri}", 0) else 0
                currentPage = savedPage.coerceIn(0, pdfRenderer!!.pageCount - 1)
                emptyMessage.visibility = View.GONE
                displayCurrent()
            } else if (mime == "image/jpeg" || mime == "image/png" ||
                name.lowercase().endsWith(".jpg") || name.lowercase().endsWith(".jpeg") || name.lowercase().endsWith(".png")) {
                contentResolver.openInputStream(uri).use { stream ->
                    imageBitmap = BitmapFactory.decodeStream(stream)
                }
                if (imageBitmap == null) throw IOException("Image format is not supported")
                isPdf = false
                currentPage = 0
                emptyMessage.visibility = View.GONE
                displayCurrent()
            } else {
                throw IOException("केवल PDF, JPG और PNG फाइलें समर्थित हैं")
            }
            prefs.edit().putString("last_uri", uri.toString()).apply()
        } catch (e: Exception) {
            Toast.makeText(this, "File नहीं खुल सकी: ${e.message}", Toast.LENGTH_LONG).show()
            closeDocument()
        }
    }

    private fun changePage(delta: Int) {
        if (!isPdf) return
        val renderer = pdfRenderer ?: return
        val next = currentPage + delta
        if (next in 0 until renderer.pageCount) {
            currentPage = next
            currentUri?.let { prefs.edit().putInt("page_$it", currentPage).apply() }
            displayCurrent()
        }
    }

    private fun displayCurrent() {
        if (isPdf) {
            val renderer = pdfRenderer ?: return
            try {
                val page = renderer.openPage(currentPage)
                val maxW = (resources.displayMetrics.widthPixels * 1.4f).toInt().coerceAtLeast(1280)
                val maxH = (resources.displayMetrics.heightPixels * 1.4f).toInt().coerceAtLeast(720)
                val scale = minOf(maxW.toFloat() / page.width, maxH.toFloat() / page.height) * zoom
                val w = (page.width * scale).toInt().coerceIn(1, 5000)
                val h = (page.height * scale).toInt().coerceIn(1, 5000)
                val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(android.graphics.Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                setDisplayedBitmap(bitmap)
                pageLabel.text = "Page ${currentPage + 1} / ${renderer.pageCount}"
            } catch (_: Exception) {
                Toast.makeText(this, "PDF page render नहीं हो सका", Toast.LENGTH_SHORT).show()
            }
        } else {
            val source = imageBitmap ?: return
            val w = (source.width * zoom).toInt().coerceIn(1, 5000)
            val h = (source.height * zoom).toInt().coerceIn(1, 5000)
            val scaled = Bitmap.createScaledBitmap(source, w, h, true)
            setDisplayedBitmap(scaled)
            pageLabel.text = "Image"
        }
    }

    private fun setDisplayedBitmap(bitmap: Bitmap) {
        if (renderedBitmap !== imageBitmap && renderedBitmap !== bitmap) renderedBitmap?.recycle()
        renderedBitmap = bitmap
        pageImage.setImageBitmap(bitmap)
    }

    private fun saveBookmark() {
        if (!isPdf || currentUri == null) {
            Toast.makeText(this, "Bookmark केवल PDF पेज के लिए उपलब्ध है", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.edit().putInt("bookmark_${currentUri}", currentPage).apply()
        Toast.makeText(this, "Bookmark saved: Page ${currentPage + 1}", Toast.LENGTH_SHORT).show()
    }

    private fun askPageNumber() {
        val renderer = pdfRenderer ?: return
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            hint = "1 - ${renderer.pageCount}"
        }
        AlertDialog.Builder(this).setTitle("Go to page")
            .setView(input)
            .setPositiveButton("Open") { _, _ ->
                val page = input.text.toString().toIntOrNull()
                if (page != null && page in 1..renderer.pageCount) {
                    currentPage = page - 1
                    currentUri?.let { prefs.edit().putInt("page_$it", currentPage).apply() }
                    displayCurrent()
                } else Toast.makeText(this, "सही page number डालें", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_PAGE_UP -> { changePage(-1); return true }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_PAGE_DOWN -> { changePage(1); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun closeDocument() {
        try { pdfRenderer?.close() } catch (_: Exception) { }
        try { descriptor?.close() } catch (_: Exception) { }
        pdfRenderer = null
        descriptor = null
        if (renderedBitmap != null && renderedBitmap !== imageBitmap) renderedBitmap?.recycle()
        renderedBitmap = null
        imageBitmap?.recycle()
        imageBitmap = null
        pageImage.setImageDrawable(null)
    }

    override fun onDestroy() {
        closeDocument()
        super.onDestroy()
    }
}
